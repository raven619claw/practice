abs = {
	a:1
}