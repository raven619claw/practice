// Since T3 exports Box as a namespace, assign a shortcut Application to Box.Application
var Application = Box.Application;